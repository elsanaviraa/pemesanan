package com.example.pemesanan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PemesananApplicationTests {

	@Test
	void contextLoads() {
	}

}
